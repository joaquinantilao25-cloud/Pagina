# Administraciones Ferrada SpA · Proyecto web V3

Sitio corporativo **HTML5 + CSS3 + JavaScript**, editable en **Visual Studio Code**, sin React, bases de datos ni suscripciones para verlo localmente. Conserva el diseño **azul marino, blanco y dorado**, fotos y videos, la información original, el formulario de la portada y las secciones de la empresa.

## 1. Abrir la página

1. Descomprima el ZIP completo.
2. En VS Code, use **Archivo → Abrir carpeta** y seleccione `Administraciones_Ferrada_WEB_V3`.
3. Abra `index.html` con **Live Server** (recomendado), o ábralo en Chrome/Edge.
4. Edite y guarde. Los cambios se reflejarán al refrescar la página.

## 2. Estructura

```text
Administraciones_Ferrada_WEB_V3/
├── index.html                 HTML5, contenido y formularios
├── assets/
│   ├── css/styles.css        Colores, responsividad, animaciones, chat
│   ├── js/main.js            Funciones interactivas, asistente y validación
│   ├── img/                  Fotografías, logotipo ilustrativo y posters
│   └── video/                3 clips MP4 usados en el sitio
└── README.md                 Manual de edición
```

## 3. Qué incluye esta versión

- Portada con videos y fotos animadas, cambio automático, puntos para elegir escena y botón para pausar.
- Menú adaptable a celulares, carrusel cinematográfico, banda de servicios en movimiento y botones con efectos de hover.
- Tarjetas interactivas con los **8 servicios** de Ferrada, equipo y **4 pasos** de cambio de administración.
- Sección de **normativa** con Ley 21.442, D.S. 7 de 2025 y 15 referencias desplegables (incluidas algunas normas históricas señaladas como tales).
- **14 compromisos de ética** desplegables.
- Preguntas frecuentes ampliadas con información general de gastos comunes, registro de administradores, cobro de morosidad y fondo de reserva.
- Formulario de **contacto** con selección de rol (comité, copropietario, residente, inmobiliaria), comunidad y comuna, teléfono, correo opcional, consulta, autorización y **dos canales de salida: correo y WhatsApp**.
- **Tres teléfonos** y correo de contacto basados en la información compartida: +56 9 5639 2635; +56 9 8560 5567; +56 9 5685 3886; contacto@administracionesferrada.cl.
- **Asistente Ferrada V3**: temas guiados, respuestas a preguntas escritas, enlaces a secciones, botón para hablar con una persona, acceso directo a correo y WhatsApp, reinicio de conversación y diseño adaptable.

## 4. Formularios: funcionamiento real

El sitio es estático: **no envía correos ni almacena solicitudes automáticamente**.

- **Preparar correo** abre el programa de email del visitante con asunto y contenido completados. El visitante debe revisar y presionar **Enviar** en su aplicación de correo.
- **Enviar por WhatsApp** abre WhatsApp con un mensaje listo. El visitante debe confirmar el envío desde la aplicación.
- El formulario superior prepara solicitudes por WhatsApp de forma similar.
- Si en el futuro necesita recepción automática, notificaciones o base de datos de solicitudes, deberá conectarse un backend seguro o un servicio profesional de formularios.

## 5. Cómo editar

**Textos y secciones:** busque `NORMATIVA`, `PREGUNTAS FRECUENTES`, `CONTACTO`, `EQUIPO` o `PORTADA` dentro de `index.html`.

**Paleta de colores y botones:** `assets/css/styles.css`. Variables principales `--navy`, `--gold` y, en V3, `--ferrada-blue`/`--ferrada-gold`.

**Videos:** archivos en `assets/video/`. Las escenas de portada están en `index.html` dentro de `hero-background`; las duraciones se expresan con `data-duration` en milisegundos.

**WhatsApp:** busque `const CONFIG` en `assets/js/main.js` y actualice `whatsapp` si cambia el número. Cambie también los números `tel:` mostrados en `index.html`.

**Email:** busque `const BUSINESS_EMAIL` en `assets/js/main.js` y actualice el correo; cambie también su aparición en `index.html`.

**Respuestas del asistente:** en `assets/js/main.js`, edite `CHAT_TOPICS` (texto + acciones) y `detectTopic` (palabras clave para preguntas abiertas). Este asistente **no está conectado a un modelo de IA**: es un orientador local que responde temas definidos y deriva cuando no sabe la respuesta. No solicita contraseñas ni accede a saldos de un edificio.

**Logotipo:** `assets/img/logo-ferrada.svg` es una propuesta gráfica ilustrativa, **no** un archivo oficial de la marca. Sustitúyalo con el logotipo aprobado.

## 6. Revisión antes de publicar

- Confirme teléfonos, email, registro PN-7228 y nombres/cargos del equipo.
- Valide el listado de normas con un profesional: **incluye referencias históricas o susceptibles de actualización**. El contenido informativo no sustituye asesoría legal ni una verificación normativa de cada caso.
- Incluya una política de privacidad real, con responsable, finalidad, conservación y derechos aplicables, antes de publicar formularios.
- Confirme que cuenta con autorización para utilizar todas las fotografías y los videos incluidos.
- No se incorporan métricas o años de experiencia inventados; los nombres del equipo aparecen sin retratos creados artificialmente.
- Pruebe el sitio en un servidor HTTPS y verifique que el programa de correo y WhatsApp funcionen para los visitantes.

## 7. Publicación

Suba `index.html` junto a la carpeta `assets` al alojamiento web de su dominio, manteniendo las rutas. Este proyecto **no modifica automáticamente** el sitio público actual; la publicación se realiza por separado.
