/* Administraciones Ferrada SpA — Interacciones HTML5 sin librerías
   CONFIGURACIÓN: cambie aquí el número de WhatsApp si la empresa lo actualiza.
   El formulario abre WhatsApp con un texto preparado: NO existe un backend de envío. */
'use strict';

const CONFIG = {
  whatsapp: '56956392635',
  mensajeInicial: 'Hola, quisiera obtener información sobre la administración de mi edificio o condominio.'
};

const $ = (selector, context = document) => context.querySelector(selector);
const $$ = (selector, context = document) => [...context.querySelectorAll(selector)];

function whatsappUrl(text) {
  return `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;
}

function openWhatsapp(text) {
  // Activación desde un clic real del visitante, con navegación estándar.
  const link = document.createElement('a');
  link.href = whatsappUrl(text);
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  link.remove();
}

// Menú accesible en teléfonos y tabletas.
const menuToggle = $('.menu-toggle');
const navLinks = $('#menu-principal');
function closeMenu() {
  menuToggle?.setAttribute('aria-expanded', 'false');
  menuToggle?.setAttribute('aria-label', 'Abrir menú');
  navLinks?.classList.remove('is-open');
}
menuToggle?.addEventListener('click', () => {
  const open = menuToggle.getAttribute('aria-expanded') !== 'true';
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
  navLinks.classList.toggle('is-open', open);
});
$$('.nav-links a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeMenu();
});
document.addEventListener('click', event => {
  if (navLinks?.classList.contains('is-open') && !event.target.closest('.nav')) closeMenu();
});

// Barra fija con cambio de sombra al desplazarse, botón volver arriba.
const siteHeader = $('.site-header');
const backToTop = $('#back-to-top');
function updateScrollUI() {
  const scrolled = window.scrollY > 24;
  siteHeader?.classList.toggle('scrolled', scrolled);
  backToTop?.classList.toggle('visible', window.scrollY > 580);
}
window.addEventListener('scroll', updateScrollUI, { passive: true });
updateScrollUI();
backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
$('#year').textContent = String(new Date().getFullYear());

// Aparecer suavemente cuando cada sección ingresa a la pantalla.
const revealItems = $$('[data-reveal]');
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const revealObserver = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    }
  }, { threshold: 0.07, rootMargin: '0px 0px 30px 0px' });
  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add('is-visible'));
}

// Actualizar automáticamente todos los botones que abren WhatsApp.
$$('.wa-direct').forEach(link => {
  link.href = whatsappUrl(CONFIG.mensajeInicial);
});

// Formulario de propuesta: valida, compone mensaje y abre WhatsApp.
const proposalForm = $('#formulario-propuesta');
const statusBox = $('#form-status');
proposalForm?.addEventListener('submit', event => {
  event.preventDefault();
  statusBox.textContent = '';
  statusBox.classList.remove('error');

  if (!proposalForm.checkValidity()) {
    statusBox.textContent = 'Complete los campos obligatorios, revise el correo si lo escribió y acepte el uso de sus datos.';
    statusBox.classList.add('error');
    proposalForm.reportValidity();
    return;
  }
  const data = new FormData(proposalForm);
  const name = String(data.get('nombre') || '').trim();
  const community = String(data.get('comunidad') || '').trim();
  const phone = String(data.get('telefono') || '').trim();
  const email = String(data.get('correo') || '').trim();
  const issue = String(data.get('necesidad') || '').trim();
  const profile = String(data.get('perfil') || '').trim();
  const message = String(data.get('mensaje') || '').trim();

  if (name.length < 3 || community.length < 3 || phone.replace(/\D/g, '').length < 8) {
    statusBox.textContent = 'Revise su nombre, comunidad y teléfono. El teléfono debe incluir al menos 8 dígitos.';
    statusBox.classList.add('error');
    return;
  }
  const text = [
    'Hola, equipo de Administraciones Ferrada SpA.',
    'Quisiera solicitar información / una propuesta de administración.',
    '',
    `Nombre: ${name}`,
    `Edificio o comunidad y comuna: ${community}`,
    `Teléfono: ${phone}`,
    profile ? `Perfil: ${profile}` : null,
    email ? `Correo electrónico: ${email}` : null,
    `Motivo: ${issue}`,
    message ? `Mensaje: ${message}` : null,
    '',
    'Enviado desde el formulario web.'
  ].filter(line => line !== null).join('\n');
  statusBox.textContent = 'Se abrirá WhatsApp con su solicitud preparada. Revise el texto y presione Enviar en WhatsApp para completar el contacto.';
  openWhatsapp(text);
});

// Diálogos de detalles: se puede ampliar este catálogo editando solo este objeto.
const serviceCatalog = {
  gastos: {
    label: '01 / FINANZAS Y ADMINISTRACIÓN', title: 'Cobro de gastos comunes',
    description: 'La organización de los gastos comunes ayuda al comité a contar con una gestión ordenada y comprensible para la comunidad.',
    points: ['Organización de la información financiera.', 'Seguimiento de cobros y pagos de gastos comunes.', 'Comunicación de antecedentes relevantes para el comité.', 'Apoyo para comprender los movimientos de la comunidad.']
  },
  morosidad: {
    label: '02 / COBRANZA', title: 'Manejo de morosidad',
    description: 'El seguimiento de las obligaciones pendientes permite anticipar dificultades de caja y trabajar soluciones dentro de las reglas aplicables.',
    points: ['Seguimiento de saldos vencidos.', 'Comunicación y gestión de cobranza.', 'Revisión de alternativas de regularización.', 'Información sobre la evolución de la morosidad.']
  },
  reserva: {
    label: '03 / PLANIFICACIÓN', title: 'Fondo de reserva',
    description: 'Una administración responsable identifica las necesidades futuras y registra el uso del fondo de reserva conforme a la normativa y los acuerdos correspondientes.',
    points: ['Seguimiento de los recursos disponibles.', 'Planificación de gastos autorizados.', 'Registro y respaldo de movimientos.', 'Comunicación a quienes corresponda.']
  },
  espacios: {
    label: '04 / CONVIVENCIA', title: 'Uso de espacios comunes',
    description: 'Los espacios comunes son parte importante de la vida de la comunidad. Su uso debe ser organizado y respetar el reglamento del condominio.',
    points: ['Organización de solicitudes de uso.', 'Coordinación de mantención y cuidado.', 'Aplicación de reglas de convivencia.', 'Comunicación de condiciones de uso.']
  },
  personal: {
    label: '05 / PERSONAS', title: 'Manejo de personal',
    description: 'La coordinación del personal favorece una operación diaria más clara y una mejor atención a residentes y visitas.',
    points: ['Supervisión y definición de funciones.', 'Coordinación del trabajo de conserjería y aseo.', 'Apoyo a los procesos operativos.', 'Comunicación de necesidades del equipo.']
  },
  seguridad: {
    label: '06 / PROTECCIÓN', title: 'Gestión de entornos seguros',
    description: 'La seguridad requiere medidas preventivas, organización y coordinación apropiadas a cada edificio o condominio.',
    points: ['Apoyo en el control de acceso.', 'Supervisión de procedimientos de seguridad.', 'Coordinación de medidas preventivas.', 'Seguimiento de situaciones informadas por la comunidad.']
  },
  riesgos: {
    label: '07 / PREVENCIÓN', title: 'Prevención de riesgos y siniestros',
    description: 'Un enfoque preventivo ayuda a identificar situaciones de riesgo y a promover el cuidado de personas e instalaciones.',
    points: ['Identificación de necesidades preventivas.', 'Coordinación de revisiones y mantenciones.', 'Difusión de recomendaciones relevantes.', 'Apoyo en procedimientos y organización ante emergencias.']
  },
  informacion: {
    label: '08 / INFORMACIÓN', title: 'Manejo de la información',
    description: 'Documentos organizados y comunicaciones claras hacen más sencilla la relación entre administración, comité y residentes.',
    points: ['Organización de antecedentes y documentación.', 'Comunicación oportuna de información.', 'Apoyo al resguardo de los registros.', 'Seguimiento de solicitudes y asuntos de gestión.']
  }
};
const extraInformation = {
  normativa: {
    label: 'NORMATIVA Y CUMPLIMIENTO', title: 'Normativa de copropiedad',
    description: 'Nuestro enfoque contempla el marco legal aplicable. El reglamento de copropiedad y la situación de cada comunidad deben examinarse en cada caso.',
    points: ['Ley N.º 21.442 sobre Copropiedad Inmobiliaria.', 'Reglamento de copropiedad de la comunidad.', 'Acuerdos de los órganos competentes.', 'Otras disposiciones aplicables según la actividad y las circunstancias del edificio.']
  },
  etica: {
    label: 'COMPROMISO PROFESIONAL', title: 'Principios de nuestro código de ética',
    description: 'Buscamos una relación de confianza y responsabilidad en cada una de nuestras gestiones.',
    points: ['Transparencia y honestidad.', 'Discreción y respeto por la información de la comunidad.', 'Lealtad e imparcialidad en nuestras decisiones.', 'Eficiencia, respeto y orientación al servicio.']
  }
};
const dialog = $('#info-dialog');
function showDetail(detail) {
  if (!dialog || !detail) return;
  $('#dialog-label').textContent = detail.label;
  $('#dialog-title').textContent = detail.title;
  $('#dialog-description').textContent = detail.description;
  const list = $('#dialog-list');
  list.replaceChildren();
  detail.points.forEach(point => {
    const li = document.createElement('li');
    li.textContent = point; // Evita inyectar HTML desde texto.
    list.appendChild(li);
  });
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
}
$$('[data-service]').forEach(card => card.addEventListener('click', () => showDetail(serviceCatalog[card.dataset.service])));
$$('.open-info').forEach(button => button.addEventListener('click', () => showDetail(extraInformation[button.dataset.info])));
$('.dialog-close')?.addEventListener('click', () => dialog.close());
$('.dialog-cta')?.addEventListener('click', () => dialog.close());
dialog?.addEventListener('click', event => {
  if (event.target === dialog) dialog.close();
});

// Un solo acordeón abierto a la vez.
$$('.faq-list details').forEach(item => item.addEventListener('toggle', () => {
  if (item.open) $$('.faq-list details').filter(other => other !== item).forEach(other => { other.open = false; });
}));

// Asistente local (V3): cargado al final de este archivo, sin APIs externas.

// Portada con dos videos y dos fotografías: transición, selección y pausa.
// Solo usa APIs estándar de los navegadores; no requiere librerías.
(() => {
  const hero = document.querySelector('.hero');
  if (!hero) return;
  const scenes = [...hero.querySelectorAll('.hero-scene')];
  const dots = [...hero.querySelectorAll('.hero-slide-dot')];
  const toggle = hero.querySelector('.hero-motion-toggle');
  const caption = hero.querySelector('#hero-media-caption');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let current = reduceMotion ? 1 : 0;
  let paused = reduceMotion;
  let onScreen = true;
  let cycleTimer = null;

  function pauseAllVideos() {
    scenes.forEach(scene => {
      const video = scene.querySelector('video');
      if (video) video.pause();
    });
  }
  function stopTimer() {
    if (cycleTimer !== null) window.clearTimeout(cycleTimer);
    cycleTimer = null;
  }
  function updateControls() {
    dots.forEach((dot, index) => {
      const active = index === current;
      dot.classList.toggle('is-active', active);
      dot.setAttribute('aria-pressed', String(active));
    });
    if (caption) caption.textContent = scenes[current]?.dataset.name || 'Fondo animado';
    if (toggle) {
      toggle.setAttribute('aria-pressed', String(paused));
      toggle.setAttribute('aria-label', paused ? 'Reanudar movimiento del fondo' : 'Pausar movimiento del fondo');
      toggle.querySelector('.hero-motion-icon').textContent = paused ? '▶' : 'Ⅱ';
      toggle.querySelector('.hero-motion-text').textContent = paused ? 'Reanudar' : 'Pausar';
    }
  }
  function playAndSchedule() {
    stopTimer();
    if (paused || document.hidden || !onScreen) return;
    const active = scenes[current];
    if (!active) return;
    const video = active.querySelector('video');
    if (video) {
      video.muted = true;
      video.currentTime = 0;
      const attempt = video.play();
      // Si autoplay no está permitido, el poster sigue visible.
      if (attempt && typeof attempt.catch === 'function') attempt.catch(() => {});
    }
    cycleTimer = window.setTimeout(() => setScene((current + 1) % scenes.length), Number(active.dataset.duration) || 7000);
  }
  function setScene(index) {
    stopTimer();
    pauseAllVideos();
    current = index;
    scenes.forEach((scene, i) => scene.classList.toggle('is-active', i === index));
    updateControls();
    playAndSchedule();
  }
  dots.forEach(dot => dot.addEventListener('click', () => {
    // Una elección expresa del visitante inicia la animación si estaba pausada.
    paused = false;
    setScene(Number(dot.dataset.slide));
  }));
  toggle?.addEventListener('click', () => {
    paused = !paused;
    if (paused) { stopTimer(); pauseAllVideos(); }
    else playAndSchedule();
    updateControls();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { stopTimer(); pauseAllVideos(); }
    else playAndSchedule();
  });
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      onScreen = entries[0]?.isIntersecting ?? true;
      if (!onScreen) { stopTimer(); pauseAllVideos(); }
      else playAndSchedule();
    }, { threshold: 0.05 }).observe(hero);
  }
  updateControls();
  setScene(current);
})();

// El video de la reunión se activa solo cuando su sección está visible.
(() => {
  const clip = document.querySelector('.about-video');
  if (!clip) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const updatePlayback = visible => {
    if (!visible || document.hidden) clip.pause();
    else {
      clip.muted = true;
      const result = clip.play();
      if (result && typeof result.catch === 'function') result.catch(() => {});
    }
  };
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => updatePlayback(entries[0].isIntersecting), { threshold: 0.15 });
    observer.observe(clip);
  } else updatePlayback(true);
  document.addEventListener('visibilitychange', () => updatePlayback(!document.hidden && clip.getBoundingClientRect().top < innerHeight && clip.getBoundingClientRect().bottom > 0));
})();

/* ============================================================
   V3 · Contacto por correo/WhatsApp + asistente guiado
   Las consultas se procesan localmente; NO es una IA en línea.
   ============================================================ */
const BUSINESS_EMAIL = 'contacto@administracionesferrada.cl';
const BUSINESS_PHONES = ['+56 9 5639 2635', '+56 9 8560 5567', '+56 9 5685 3886'];
const contactForm = document.querySelector('#formulario-contacto');
let outgoingChannel = 'correo';
contactForm?.querySelectorAll('button[data-channel]').forEach(button => {
  button.addEventListener('click', () => { outgoingChannel = button.dataset.channel; });
});
contactForm?.addEventListener('submit', event => {
  event.preventDefault();
  const status = document.querySelector('#contacto-status');
  status.textContent = '';
  status.classList.remove('error');
  if (!contactForm.checkValidity()) {
    status.textContent = 'Por favor complete los campos marcados y acepte el uso de datos.';
    status.classList.add('error');
    contactForm.reportValidity();
    return;
  }
  const fields = new FormData(contactForm);
  const name = String(fields.get('nombre') || '').trim();
  const community = String(fields.get('comunidad') || '').trim();
  const phone = String(fields.get('telefono') || '').trim();
  const email = String(fields.get('correo') || '').trim();
  const message = String(fields.get('mensaje') || '').trim();
  const profile = String(fields.get('perfil') || '').trim();
  if (phone.replace(/\D/g, '').length < 8 || name.length < 3 || community.length < 3 || message.length < 8) {
    status.textContent = 'Revise nombre, edificio/comuna, teléfono y consulta. El teléfono debe tener al menos 8 dígitos.';
    status.classList.add('error'); return;
  }
  const text = [
    'Hola, Administraciones Ferrada SpA:',
    'Deseo solicitar información o una propuesta.',
    '', `Nombre: ${name}`, `¿Quién consulta?: ${profile}`, `Edificio y comuna: ${community}`, `Teléfono: ${phone}`,
    email ? `Correo: ${email}` : null, '', `Consulta: ${message}`, '', 'Solicitud preparada desde el sitio web.'
  ].filter(line => line !== null).join('\n');
  if (outgoingChannel === 'whatsapp') {
    status.textContent = 'Se abrirá WhatsApp con el mensaje listo para revisar. Debe pulsar Enviar allí.';
    openWhatsapp(text);
  } else {
    const subject = `Solicitud de administración - ${community}`;
    const uri = `mailto:${BUSINESS_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
    status.textContent = 'Se abrirá su aplicación de correo con el mensaje preparado. Compruebe su contenido y envíelo allí.';
    window.location.href = uri;
  }
});

// Botones de las preguntas frecuentes abren un asistente único.
const chatLaunch = document.querySelector('#chat-launch');
const chatPanel = document.querySelector('#chat-panel');
const chatMessages = document.querySelector('#chat-messages');
const chatActions = document.querySelector('#chat-actions');
const chatInput = document.querySelector('#chat-question');
const chatForm = document.querySelector('#chat-form');
let chatContext = 'inicio';
let chatBusy = false;
let pendingChatReplies = [];
const normal = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9ñ\s]/g, ' ').replace(/\s+/g, ' ').trim();
const CHAT_TOPICS = {
  inicio: {
    text: '¡Hola! 👋 Soy el asistente de orientación de Administraciones Ferrada. Puedo ayudarle con administración de edificios, gastos comunes, normativa y consultas de residentes. ¿Cuál es su caso?',
    actions: [['🏢 Quiero administración para mi edificio','propuesta'],['🔄 Quiero cambiar de administración','cambio'],['🏠 Soy copropietario o residente','residente'],['📋 Servicios','servicios'],['❓ Preguntas frecuentes','faqs'],['⚖ Normativa','normativa'],['☎ Hablar con una persona','humano']]
  },
  propuesta: {
    text: 'Para preparar una propuesta, necesitamos conocer el edificio o condominio, su comuna, número aproximado de unidades y qué servicios desea mejorar. Puede completar el formulario de contacto o conversar directamente con un asesor. No informamos precios sin conocer la comunidad.',
    actions: [['📝 Completar formulario','formulario'],['💬 Preparar WhatsApp','wa-propuesta'],['🔄 ¿Cómo se cambia?','cambio'],['↩ Menú principal','inicio']]
  },
  cambio: {
    text: 'El cambio se organiza en 4 pasos: 1) nos cuenta sobre su comunidad, 2) revisamos reglamento, gastos comunes, personal y seguros, 3) enviamos una propuesta escrita y 4) tras la aprobación correspondiente, realizamos el traspaso ordenado. La aprobación se rige por la Ley 21.442 y el reglamento aplicable.',
    actions: [['↗ Ver los cuatro pasos','ir-cambio'],['📝 Solicitar evaluación','formulario'],['⚖ ¿Quién aprueba el cambio?','aprobacion'],['↩ Menú principal','inicio']]
  },
  aprobacion: {
    text: 'La designación y remoción del administrador debe ajustarse a la Ley 21.442, los acuerdos del órgano competente y los procedimientos de la comunidad. Una propuesta comercial no reemplaza la aprobación legalmente exigida.',
    actions: [['↗ Ver cómo cambiarse','ir-cambio'],['⚖ Ver marco legal','ir-normativa'],['☎ Hablar con un asesor','humano'],['↩ Menú','inicio']]
  },
  residente: {
    text: '¡Bienvenido/a! Si es copropietario o residente, puedo orientarle sobre gastos comunes, morosidad, fondo de reserva, uso de espacios comunes, mantención y formas de contactar al equipo. No tengo acceso a los saldos ni a información privada de su condominio.',
    actions: [['💰 Gastos comunes','gastos'],['📉 Morosidad','morosidad'],['🏦 Fondo de reserva','reserva'],['🏡 Espacios comunes','espacios'],['📞 Contacto','humano'],['↩ Menú','inicio']]
  },
  servicios: {
    text: 'Ofrecemos ocho líneas de servicio: cobro de gastos comunes, morosidad, fondo de reserva, espacios comunes, manejo de personal, entornos seguros, prevención de riesgos y manejo de la información. El alcance concreto se define con cada comunidad.',
    actions: [['💰 Gastos comunes','gastos'],['🛡 Seguridad','seguridad'],['🧹 Personal y mantención','personal'],['↗ Ver todos los servicios','ir-servicios'],['↩ Menú','inicio']]
  },
  gastos: {
    text: 'Los gastos comunes cubren la operación de la comunidad y se distribuyen conforme a la Ley 21.442 y su reglamento de copropiedad. El aviso de cobro debe informar los conceptos y movimientos relevantes. Podemos orientar sobre organización, cobro y seguimiento.',
    actions: [['📉 ¿Qué pasa con la morosidad?','morosidad'],['🏦 Fondo de reserva','reserva'],['📝 Solicitar propuesta','propuesta'],['↩ Menú','inicio']]
  },
  morosidad: {
    text: 'La morosidad requiere seguimiento de pagos pendientes, comunicación y gestión de cobranza de acuerdo con la ley y el reglamento de la comunidad. Cuando corresponda se estudian alternativas de regularización; no podemos confirmar deudas personales desde este chat.',
    actions: [['💰 Gastos comunes','gastos'],['⚖ Ley 21.442','normativa'],['☎ Hablar con una persona','humano'],['↩ Menú','inicio']]
  },
  reserva: {
    text: 'El fondo común de reserva permite afrontar principalmente gastos extraordinarios, urgentes o imprevistos. La Ley 21.442, artículo 39, regula su constitución y el uso de los recursos; las autorizaciones dependen del tipo de gasto.',
    actions: [['💰 Gastos comunes','gastos'],['⚖ Ver normativa','ir-normativa'],['↩ Menú','inicio']]
  },
  espacios: {
    text: 'Los espacios comunes —salas multiuso, piscinas y otros recintos— se usan según el reglamento, los acuerdos aplicables y las medidas de seguridad. Podemos apoyar su organización, cuidado y mantenimiento.',
    actions: [['🔧 Mantención y personal','personal'],['🛡 Seguridad','seguridad'],['↩ Menú','inicio']]
  },
  seguridad: {
    text: 'La gestión preventiva puede incluir coordinación de controles de acceso, supervisión de servicios, planificación ante emergencias y seguimiento de necesidades del edificio. Las medidas específicas se revisan para cada comunidad.',
    actions: [['🔧 Personal y mantención','personal'],['↗ Ver servicios','ir-servicios'],['📝 Pedir propuesta','formulario'],['↩ Menú','inicio']]
  },
  personal: {
    text: 'La coordinación de personal contempla apoyo en la supervisión de conserjería, aseo y mantención, definición de responsabilidades y seguimiento de tareas. Las condiciones específicas dependen de los contratos y acuerdos de la comunidad.',
    actions: [['🛡 Entornos seguros','seguridad'],['🏡 Áreas comunes','espacios'],['↗ Ver servicios','ir-servicios'],['↩ Menú','inicio']]
  },
  normativa: {
    text: 'La principal norma es la Ley 21.442 de Copropiedad Inmobiliaria y su reglamento general, el D.S. 7 publicado en 2025. Existe además un Registro Nacional de Administradores del MINVU. La sección Normativa reúne referencias legales y 14 compromisos éticos. Para una situación particular conviene revisar el reglamento del condominio.',
    actions: [['⚖ Ver las 15 referencias','ir-normativa'],['📜 Código de ética','etica'],['🪪 Registro de administradores','registro'],['↩ Menú','inicio']]
  },
  registro: {
    text: 'La inscripción en el Registro Nacional de Administradores de Condominios del MINVU es obligatoria para quienes ejercen la administración. Ferrada informa el registro N.º PN-7228 en sus antecedentes comerciales; la vigencia se debe consultar en el registro oficial.',
    actions: [['⚖ Ver normativa','ir-normativa'],['☎ Contactar al equipo','humano'],['↩ Menú','inicio']]
  },
  etica: {
    text: 'Nuestro código de ética se inspira en 14 compromisos: transparencia, diligencia, discreción, formación continua, respeto, decisiones responsables, comunicación oportuna y resguardo de información confidencial, entre otros.',
    actions: [['📜 Leer los 14 compromisos','ir-etica'],['⚖ Referencias normativas','ir-normativa'],['↩ Menú','inicio']]
  },
  faqs: {
    text: 'Estas son las consultas más comunes: qué ley regula a los condominios, si los administradores deben inscribirse, cómo cambiar de administración, cómo se calculan los gastos comunes, qué hacer ante morosidad y cómo funciona el fondo de reserva.',
    actions: [['↗ Leer preguntas frecuentes','ir-faq'],['⚖ Ley 21.442','normativa'],['💰 Gastos comunes','gastos'],['↩ Menú','inicio']]
  },
  humano: {
    text: `Nuestro equipo puede orientarle directamente. Teléfonos: ${BUSINESS_PHONES.join(' · ')}. Correo: ${BUSINESS_EMAIL}. También puede abrir WhatsApp con un mensaje inicial listo para enviar.`,
    actions: [['💬 Abrir WhatsApp','wa-humano'],['✉ Preparar correo','email'],['📝 Ir al formulario','formulario'],['↩ Menú','inicio']]
  },
  privacidad: {
    text: 'Este asistente funciona mediante respuestas predefinidas en su navegador. No accede a bases de datos de su condominio, no pide claves ni documentos y no transmite lo que escribe a un servidor de IA. Los formularios solo preparan mensajes para su envío manual por correo o WhatsApp.',
    actions: [['↗ Ver uso de datos','ir-privacidad'],['☎ Contactar','humano'],['↩ Menú','inicio']]
  },
  desconocido: {
    text: 'Puedo ayudarle con gastos comunes, fondo de reserva, cambio de administración, Ley 21.442, servicios y solicitudes de propuesta. Si su caso es particular, lo más apropiado es conversarlo con nuestro equipo.',
    actions: [['📋 Servicios','servicios'],['⚖ Normativa','normativa'],['☎ Hablar con una persona','humano'],['↩ Menú','inicio']]
  }
};
function detectTopic(raw) {
  const text = normal(raw);
  const tests = [
    ['privacidad', /privacidad|datos personales|guardan|proteccion de datos|clave|contraseña/],
    ['humano', /hablar con (una persona|alguien|humano|asesor)|contacto|telefono|llamar|whatsapp|correo|email|horario|direccion/],
    ['registro', /registro|inscrit|pn 7228|minvu|numero de administrador/],
    ['aprobacion', /quien aprueba|quien puede cambiar|quien designa|quien nombra|votacion|asamblea/],
    ['etica', /etica|honradez|compromisos|principios/],
    ['normativa', /ley|decreto|normativa|reglamento|21 442|ds 7|copropiedad inmobiliaria/],
    ['cambio', /cambiar|cambio|traspaso|otra administracion|reemplaz|nuevo administrador/],
    ['morosidad', /moros|deuda|no paga|impago|atras|cobranza|pago pendiente/],
    ['reserva', /fondo|reserva|imprevisto/],
    ['gastos', /gasto|comunes|prorrateo|cobro|boleta|factura|presupuesto mensual/],
    ['espacios', /piscina|quincho|sala multiuso|areas comunes|espacios comunes|estacionamiento/],
    ['seguridad', /segur|acceso|camara|riesgo|siniestro|emergencia/],
    ['personal', /personal|aseo|mantencion|conserj|guardia|manteni|trabajador/],
    ['propuesta', /propuesta|cotizar|cotizacion|precio|valor|costo|evaluaci|presupuesto de administracion/],
    ['servicios', /servicios|que hacen|ofrecen|incluye/],
    ['residente', /residente|arrendatario|soy propietario|copropietario/],
    ['faqs', /preguntas frecuentes|dudas frecuentes/],
    ['inicio', /^hola|^buenas|^buenos|^gracias|^menu|^ayuda/]
  ];
  return tests.find(([,pattern]) => pattern.test(text))?.[0] || 'desconocido';
}
function chatBubble(message, who='bot') {
  const item=document.createElement('div');
  item.className=`chat-message ${who}`;
  item.textContent=message;
  chatMessages.appendChild(item);
  chatMessages.scrollTop=chatMessages.scrollHeight;
  return item;
}
function chatQuickActions(actions) {
  chatActions.replaceChildren();
  for (const [label,key] of actions) {
    const btn=document.createElement('button');
    btn.type='button'; btn.textContent=label; btn.className='chat-chip'; btn.dataset.action=key;
    btn.addEventListener('click', () => chatNavigate(key,true));
    chatActions.appendChild(btn);
  }
  chatActions.scrollTop=0;
}
function chatWelcome() {
  pendingChatReplies.forEach(window.clearTimeout);
  pendingChatReplies=[]; chatBusy=false; chatContext='inicio';
  chatMessages.replaceChildren();
  const date=document.createElement('div');date.className='chat-conversation-label'; date.textContent='ORIENTACIÓN AUTOMÁTICA · ADMINISTRACIONES FERRADA';chatMessages.appendChild(date);
  chatBubble(CHAT_TOPICS.inicio.text);
  chatQuickActions(CHAT_TOPICS.inicio.actions);
}
function chatExternalAction(key) {
  const sectionMap={'formulario':'#contacto','ir-cambio':'#cambiarse','ir-servicios':'#servicios','ir-normativa':'#normativa','ir-etica':'#detalle-etica','ir-faq':'#preguntas','ir-privacidad':'#privacidad-datos'};
  if (key in sectionMap) {
    const target=document.querySelector(sectionMap[key]);
    if (key==='ir-normativa') document.querySelector('#detalle-normas').open=true;
    if (key==='ir-etica') document.querySelector('#detalle-etica').open=true;
    toggleChat(false);
    target?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    if (key==='formulario') document.querySelector('#contacto-nombre')?.focus({preventScroll:true});
    return true;
  }
  if (key==='wa-humano'||key==='wa-propuesta') {
    openWhatsapp(key==='wa-propuesta'?'Hola, Administraciones Ferrada. Me interesa recibir una propuesta de administración para mi edificio/condominio.':'Hola, Administraciones Ferrada. Quisiera hablar con una persona del equipo sobre una consulta.');
    return true;
  }
  if (key==='email') {window.location.href=`mailto:${BUSINESS_EMAIL}?subject=${encodeURIComponent('Consulta desde la web - Administraciones Ferrada')}`;return true;}
  return false;
}
function chatNavigate(key, fromAction=false) {
  if (chatBusy) return;
  if (chatExternalAction(key)) return;
  const topic=CHAT_TOPICS[key]||CHAT_TOPICS.desconocido;
  if (fromAction) {
    const trigger=[...chatActions.children].find(button=>button.dataset.action===key);
    if (trigger) chatBubble(trigger.textContent.replace(/^[^\p{L}\p{N}]+/u,'').trim(),'user');
  }
  chatContext=key; chatBusy=true;
  chatActions.replaceChildren();
  const typing=document.createElement('div');typing.className='chat-typing';typing.textContent='Ferrada está preparando una respuesta';typing.setAttribute('aria-label','Preparando respuesta');chatMessages.appendChild(typing);chatMessages.scrollTop=chatMessages.scrollHeight;
  const timer=window.setTimeout(()=>{
    typing.remove();chatBubble(topic.text);chatQuickActions(topic.actions);chatBusy=false;pendingChatReplies=pendingChatReplies.filter(t=>t!==timer);
  },380);
  pendingChatReplies.push(timer);
}
function toggleChat(force) {
  const open=typeof force==='boolean'?force:chatPanel.hidden;
  chatPanel.hidden=!open;
  chatLaunch.setAttribute('aria-expanded',String(open));
  document.body.classList.toggle('chat-is-open',open);
  if (open) chatInput.focus(); else chatLaunch.focus();
}
chatLaunch?.addEventListener('click',()=>toggleChat());
document.querySelector('#chat-close')?.addEventListener('click',()=>toggleChat(false));
document.querySelector('#chat-reset')?.addEventListener('click',()=>{chatWelcome();chatInput.focus()});
document.querySelectorAll('.faq-open-chat').forEach(button=>button.addEventListener('click',()=>{toggleChat(true);chatNavigate('faqs');}));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&chatPanel&&!chatPanel.hidden)toggleChat(false)});
chatForm?.addEventListener('submit',event=>{
  event.preventDefault();
  if(chatBusy)return;
  const question=chatInput.value.trim();
  if(!question)return;
  chatBubble(question,'user');
  chatInput.value='';
  chatNavigate(detectTopic(question));
  chatInput.focus();
});
chatWelcome();
